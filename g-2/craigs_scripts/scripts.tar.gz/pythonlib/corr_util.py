#!/usr/local/bin/python3

import sys
##from numpy import *
import numpy as np
import math
import matplotlib.pyplot as plt
import re

##
##  Common jackknie routines
##

import math

def jackknife(jloop,nsample):
  jmean = 0.0
  for isample in  range(0,nsample) :
    jmean += jloop[isample]

  jmean  /= nsample

  jtot = 0.0
  for isample in  range(0,nsample) :
    ttt   = (jloop[isample] - jmean )
    jtot +=  ttt * ttt

  return math.sqrt( (nsample - 1.0)/(1.0*nsample) * jtot     )



def load_data(filename_in, nt,no_config, scale = 1.0 ):

  corr = np.zeros(( nt,no_config ))

  print ("Loading correlators from " , filename_in )
  try:
    f = open(filename_in, "r")
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  iconfig = 0 
  for line in f:
    ll  = line.rstrip('\n')
    tmp = ll.split()
    tmp.pop(0)

    t = 0 
    for xx in tmp:
#      print (xx)
      corr[t,iconfig] = scale*float(xx)
      t = t + 1
    iconfig = iconfig + 1
#
  return corr
#

#
#  Load data in gpl format
#

def load_data_gpl(filename_in, nt,no_config, tag, scale = 1.0 ):

  corr = np.zeros(( nt,no_config ))

  print ("Loading correlators from " , filename_in )
  try:
    f = open(filename_in, "r")
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  iconfig = 0 
  for line in f:
    ll  = line.rstrip('\n')
    tmp = ll.split()
    tag_f = tmp.pop(0)

    if not re.search( tag ,   tag_f ) :
      continue

#    print("DEBUG " , tag_f)
    t = 0 
    for xx in tmp:
#      print (xx)
      corr[t,iconfig] = scale*float(xx)
      t = t + 1
    iconfig = iconfig + 1
#
  return corr
#




#
#  Wite corr in gpl format
#

def write_data_gpl(corr, filename, nt,no_config, tag):

  print ("Writing correlators to " , filename, " in gpl format" )
  try:
    f = open(filename, "w")
  except:
    print ("Error opening " , filename)
    sys.exit(1)

  for iconfig in range(0, no_config) :
    f.write(tag + " " )
    for t in range(0,nt) :
       f.write(str(corr[t,iconfig]) +  " " )
    f.write("\n")

  f.close()

##
#   Average two data files together
##

def load_data_2_average_gpl(filenameP,filenameM, nt,no_config, tagP,tagM, scale = 1.0 ):

   corrP = load_data_gpl(filenameP, nt,no_config, tagP, scale)
   corrM = load_data_gpl(filenameM, nt,no_config, tagM, scale)

   corr = np.zeros(( nt,no_config ))
   for t in range(0,nt) :
     for ii in range(0,no_config) :
             corr[t,ii] = 0.5 * (corrP[t,ii] + corrM[t,ii]) 

   return corr

def count_data(filename_in):

#  print ("Loading correlators from " , filename_in, " to count" )
  try:
    f = open(filename_in, "r")
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  iconfig = 0 
  for line in f:
    iconfig = iconfig + 1

  f.close()


  return iconfig
#


#
#  gpl format
#

def count_data_gpl(filename_in, tag):

#  print ("Loading correlators from " , filename_in, " to count. Looking for" , tag)
  try:
    f = open(filename_in, "r")
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  iconfig = 0 
  for line in f:
    ll  = line.rstrip('\n')

    if not re.search( tag ,   ll ) :
      continue

    iconfig = iconfig + 1

  f.close()


  return iconfig
#



def calc_meff(corr, nt,no_config, ss = 0, ainv = 1) :

    tmp  = np.zeros(( no_config ))

    tmax = int(nt / 2)  - 1
    tt     = np.zeros(( tmax ))
    mm     = np.zeros(( tmax ))
    mm_err = np.zeros(( tmax ))
  
    for t in range(0,tmax):
       tt[t] = t + ss
       now = 0.0
       inc = 0.0 
       for i in range(0, no_config  ):
          ok = True

          now = now + corr[t,i] 
          inc = inc + corr[t+1,i] 

          #  jackknife analysis
          jnow = 0
          jinc = 0
          for j in range(0, no_config  ):
            if i != j :
              jnow = jnow + corr[t  ,j] 
              jinc = jinc + corr[t+1,j] 

          jnow = jnow / (no_config - 1) 
          jinc = jinc / (no_config - 1) 
          if jnow > 0 and jinc > 0 :
             tmp[i] = math.log(jnow / jinc)
          else:
             ok = False

       now = now / no_config
       inc = inc / no_config

       if (now > 0 and inc > 0) and ok   :
          meff = ainv * math.log(now/inc)
          jerr = ainv * jackknife(tmp,no_config)
       else:
          meff = -1
          jerr = 0.0

       mm[t]     = meff
       mm_err[t] = jerr

#       print(t, meff, jerr)


    return tt, mm, mm_err


#
#   Ratio corr  <C(t)> / <D(t) >
#


def calc_ratio_corr(corrT,corrB, nt,no_config, ss = 0, ainv = 1) :

    tmp  = np.zeros(( no_config ))

    tmax = nt 
    tt     = np.zeros(( tmax ))
    mm     = np.zeros(( tmax ))
    mm_err = np.zeros(( tmax ))
  
    for t in range(0,tmax):
       tt[t] = t + ss
       nowT = 0.0
       nowB = 0.0
       for i in range(0, no_config  ):
          nowT = nowT + corrT[t,i] 
          nowB = nowB + corrB[t,i] 
          #  jackknife analysis
          jnowT = 0
          jnowB = 0
          for j in range(0, no_config  ):
            if i != j :
              jnowT = jnowT + corrT[t  ,j] 
              jnowB = jnowB + corrB[t  ,j] 

          jnow = jnowT/jnowB 
          # tmp[i] = jnow / (no_config - 1)  
          tmp[i] = jnow 


       mm[t]     = (nowT/nowB) 
       mm_err[t] = jackknife(tmp,no_config)
        

    return tt, mm, mm_err


#  Ratio
#  average on config
#

def calc_ratio_corr_config(corrT,corrB, nt,no_config, ss = 0, ainv = 1) :

    tmp  = np.zeros(( no_config ))

    tmax = nt 
    tt     = np.zeros(( tmax ))
    mm     = np.zeros(( tmax ))
    mm_err = np.zeros(( tmax ))
  
    for t in range(0,tmax):
       tt[t] = t + ss
       nowT = 0.0
       for i in range(0, no_config  ):
          nowT = nowT + corrT[t,i] / corrB[t,i] 
          #  jackknife analysis
          jnowT = 0
          for j in range(0, no_config  ):
            if i != j :
              jnowT = jnowT + corrT[t  ,j] / corrB[t  ,j] 

          tmp[i] = jnowT/ (no_config - 1)  


       mm[t]     = nowT/ (no_config)  
       mm_err[t] = jackknife(tmp,no_config)
        

    return tt, mm, mm_err


#  Ratio
#  average on config
#  Subtract 1

def calc_ratio_corr_config_one(corrT,corrB, nt,no_config, ss = 0, ainv = 1) :

    tmp  = np.zeros(( no_config ))

    tmax = nt 
    tt     = np.zeros(( tmax ))
    mm     = np.zeros(( tmax ))
    mm_err = np.zeros(( tmax ))
  
    for t in range(0,tmax):
       tt[t] = t + ss
       nowT = 0.0
       for i in range(0, no_config  ):
          nowT = nowT + corrT[t,i] / corrB[t,i] 
          #  jackknife analysis
          jnowT = 0
          for j in range(0, no_config  ):
            if i != j :
              jnowT = jnowT + corrT[t  ,j] / corrB[t  ,j] 

          tmp[i] = jnowT/ (no_config - 1)   - 1.0


       mm[t]     = nowT/ (no_config)  - 1.0
       mm_err[t] = jackknife(tmp,no_config)
        

    return tt, mm, mm_err




#  corrT/corrB at a specific time
#  
#

def calc_ratio_corr_config_at_time(corrT,corrB, nt,no_config, ttt, ss = 0) :

    corrR  = np.zeros(( no_config ))
    traj   = np.zeros(( no_config ))

    for i in range(0, no_config  ):
      traj[i] = i + ss
      corrR[i]  =  corrT[ttt,i] / corrB[ttt,i] 

    return traj,corrR




def calc_corr(corr, nt,no_config, ss = 0, ainv = 1) :

    tmp  = np.zeros(( no_config ))

    tmax = nt 
    tt     = np.zeros(( tmax ))
    mm     = np.zeros(( tmax ))
    mm_err = np.zeros(( tmax ))
  
    for t in range(0,tmax):
       tt[t] = t + ss
       now = 0.0
       for i in range(0, no_config  ):
          now = now + corr[t,i] 
          #  jackknife analysis
          jnow = 0
          for j in range(0, no_config  ):
            if i != j :
              jnow = jnow + corr[t  ,j] 

          jnow = jnow / (no_config - 1) 
          tmp[i] = jnow 


       mm[t]     = now / no_config
       mm_err[t] = jackknife(tmp,no_config)
        

    return tt, mm, mm_err



##
##
##


def load_time_series(filename_in, tag ):

  print ("Loading correlators from " , filename_in )
  try:
    f = open(filename_in, "r")
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  iconfig = 0 
  corr = [] 
  traj = [] 

  for line in f:
    ll  = line.rstrip('\n')
    tmp = ll.split()
    ttt_ = tmp[0]
    ttt = ttt_.replace(tag , "")
    ccc = float(tmp[1])
#    print(ttt, ccc)
    traj.append(int(ttt))
    corr.append(ccc)

  return traj, corr
