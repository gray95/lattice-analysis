#  Routines to work with correlators in panda data frames
#
#


import pandas  as pd
import numpy as np
import math
import sys


import corr_util

#
#  
#

def get_mean_corr(df,nt,ss=0) :
   """
   Extract mean corr and error from dataframe
   """
   ll = len(df['0'])
   print("Number configurations " , ll)

   tt = [] 
   cc = [] 
   cc_err = [] 

   for t in range(0,nt) :
     t_ = str(t)
     ans = df[t_].mean()
     std = df[t_].std() / math.sqrt(ll)
#     print(t, ans, "+/-" , std)

     tt.append(t + ss)
     cc.append(ans)
     cc_err.append(std)
  

   return tt,cc,cc_err




#
#  
#

def dump_corr_lepage_format(df,nt,fname, tag) :
   """
   Write then correlators in Lepage format
   """

   try:
     file1 = open(fname,"w")
   except:
     print("Error writing GPL correlators to " , fname)
     sys.exit(0)

   print("Writing GPL correlators to " , fname)

   for index, row in df.iterrows():
#       print("Swwep " , index  )
       file1.write(tag + " ")
       for t in range(0,nt) :
          t_ = str(t)
          ans = row[t_]
##          print(t, ans)
          file1.write(str(ans) + " ")

       file1.write("\n")

   file1.close()  





#
#  
#

def get_meff(df,nt,ss=0) :
   """
   Extract mean corr and error from dataframe
   """
   noconfig = len(df['0'])
   print("get_meff::Number configurations " , noconfig)

##   print("DEBUG " ,  df['0'].to_numpy())

   tmp  = np.zeros(( noconfig ))
   tt = [] 
   cc = [] 
   cc_err = [] 

   for t in range(0,nt-1) :
     t_now    = str(t)
     corr_now = df[t_now].mean()

     t_inc    = str(t+1)
     corr_inc = df[t_inc].mean()

     ok = True
     
     if corr_now <= 0 and corr_inc <= 0 :
       ok = False


     #  jackknife analysis
     c_now = df[t_now].to_numpy()
     c_inc = df[t_inc].to_numpy()

     for i in range(0,noconfig) :
        jnow = 0
        jinc = 0
        for j in range(0,noconfig) :
          if  i != j :
             jnow += c_now[j]
             jinc += c_inc[j]

        jnow = jnow / (noconfig - 1) 
        jinc = jinc / (noconfig - 1) 
        if jnow > 0 and jinc > 0 :
           tmp[i] = math.log(jnow / jinc)
        else:
           ok = False

#     print("DEBUG tmp = " , tmp )
     if ok :
       meff = math.log( corr_now /  corr_inc)
       err = corr_util.jackknife(tmp,noconfig)
     else:
       meff = -1
       err = -1

     print(meff, err)
     tt.append(t + ss)
     cc.append(meff)
     cc_err.append(err)
  

   return tt,cc,cc_err




#
#  
#

def get_ratio(df_top, df_bot,nt,ss=0) :
   """
   Extract <df_top>/<df_bot>  and error from dataframe
   """
   noconfig = len(df_top['0'])
   print("get_ratio::Number configurations " , noconfig)

##   print("DEBUG " ,  df['0'].to_numpy())

   tmp  = np.zeros(( noconfig ))
   tt = [] 
   cc = [] 
   cc_err = [] 

   for t in range(0,nt) :
     t_now    = str(t)

     corr_top = df_top[t_now].mean()
     corr_bot = df_bot[t_now].mean()

     #  jackknife analysis
     c_top = df_top[t_now].to_numpy()
     c_bot = df_bot[t_now].to_numpy()

     for i in range(0,noconfig) :
        jnow = 0
        jinc = 0
        for j in range(0,noconfig) :
          if  i != j :
             jnow += c_top[j]
             jinc += c_bot[j]

        jnow = jnow / (noconfig - 1) 
        jinc = jinc / (noconfig - 1) 
        tmp[i] = jnow / jinc


#     print("DEBUG tmp = " , tmp )
     meff = ( corr_top /  corr_bot)
     err = corr_util.jackknife(tmp,noconfig)

##     print(meff, err)
     tt.append(t + ss)
     cc.append(meff)
     cc_err.append(err)
  

   return tt,cc,cc_err


#  
#  load corr file
#
#  https://www.datacamp.com/community/tutorials/pandas-read-csv

def load_corr(name, corr_tag) :

  df = pd.read_csv(name)

  if not corr_tag :
    print("No correlator tag")
    return df, 0.0

  print("Data loaded from " , name)
  print(df.head(5))

  print("All quark masses found = ", df["qmass"].unique())

  print("Selected correlator tag " , corr_tag)
  df = df[df['corr_tag'] == corr_tag]
  if df.empty :
     print("Error empty dataframe ")
     sys.exit(0)

  qm_ = df["qmass"].unique()
  print("Selected Quark mass = " , qm_)
  if len(qm_) != 1 :
    print("Error number of quark masses \n")
    sys.exit(1)

  df.drop(["qmass"], inplace=True, axis=1)


  df.drop(['corr_tag'], inplace=True, axis=1)
  df.sort_values(by=['sweep'], ascending=False, inplace=True)
  df.reset_index(drop=True, inplace=True)

  print("End of read and sort")

  return df, qm_[0]


#
#
#

def average_source(df_in, t_list) :
  """
    Average the correlators over the time sources t_list

  """

  print("Start to average over time sources ", t_list)
  df_av = df_in[df_in["tsrc"] == t_list[0]].copy()
  df_av.drop(["tsrc"], inplace=True, axis=1)

  df_av.reset_index(drop=True, inplace=True)

  print("tsrc = 0 ")
  print(df_av.head(5))

  dim = len(t_list)

  for t in t_list[1:] :
    df_ = df_in[df_in["tsrc"] == t ].copy()
    df_.drop(["tsrc"], inplace=True, axis=1)
    df_.reset_index(drop=True, inplace=True)

    df_av += df_

  df_av /= dim

  print("Averaged correlators")
  print(df_av.head(5))
#  print(df_.head(5))

  return df_av 



def average_prec_source(df_p, df_l, t_star, t_list) :
  """
    Average the correlators over the time sources t_list
    corr_p(t_star) - corr_l(t_star) + \sum_av  corr_l 9t_

   df_l loose
   df_p precise

  """

  print("Start to average over time sources ", t_list)
  df_av = df_l[df_l["tsrc"] == t_list[0]].copy()
  df_av.drop(["tsrc"], inplace=True, axis=1)

  df_av.reset_index(drop=True, inplace=True)

  print("tsrc = 0 ")
  print(df_av.head(5))

  dim = len(t_list)

  for t in t_list[1:] :
    df_ = df_l[df_l["tsrc"] == t ].copy()
    df_.drop(["tsrc"], inplace=True, axis=1)
    df_.reset_index(drop=True, inplace=True)

    df_av += df_

  df_av /= dim

  print("Averaged correlators")
  print(df_av.head(5))
#  print(df_.head(5))

  if  1 :
     # precise correlators at t = tstar
     df_ = df_p[df_p["tsrc"] == t_star ].copy()
     df_.drop(["tsrc"], inplace=True, axis=1)
     df_.reset_index(drop=True, inplace=True)
     df_av += df_

     # loose corrections
     df_ = df_l[df_l["tsrc"] == t_star ].copy()
     df_.drop(["tsrc"], inplace=True, axis=1)
     df_.reset_index(drop=True, inplace=True)
     df_av -= df_


  return df_av 
