import os
import re
import sys

timeAV=1
NOtimeAV=0

#
#  Read hadron data from a MILC data file
#
def extract_data(filename_in,tag):

#  print ("Reading data from  " , filename_in)
  try:
    f = open(filename_in, 'r')
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  store = [] 

  ct = 0 
  dump = 0  
  once = 1

  for line in f:
    ct = ct + 1
    
    ll  = line.rstrip('\n')

    if "antiquark_source_origin" in ll :
       lls = ll.split()
       print(ll)
       print(lls[5])

    if re.search( r'---'  ,   ll ) :
      dump = 0
      ct = 0 

    if dump  and ct > 2 :
      tmp = ll.split()
#      print(tmp[1])
      store.append(float(tmp[1]  ) )

    if re.search( tag  ,   ll ) and once :
      dump =  1
      ct = 0 
      once = 0 

    ct = ct + 1

  f.close



  return store





#
#  Read hadron data from a MILC data file
#
def extract_data_tsrc(filename_in,tag):

#  print ("Reading data from  " , filename_in)
  try:
    f = open(filename_in, 'r')
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  store = [] 

  ct = 0 
  dump = 0  
  once = 1
  tsrc = -3
  tsrc_ = -2
  qmass = "XXX"

  for line in f:
    ct = ct + 1
    
    ll  = line.rstrip('\n')

    if "antiquark_source_origin" in ll :
       lls = ll.split()
#       print(ll)
#       print(lls[5])
       tsrc_ =  int( lls[5] )

    if re.search(r"^quark_mass" , ll ) :
      tmp = ll.split()
      qmass_ = re.sub("\"", "", tmp[1])
#      print(qmass_)

    if re.search( r'---'  ,   ll ) :
      dump = 0
      ct = 0 

    if dump  and ct > 2 :
      tmp = ll.split()
#      print(tmp[1])
      store.append(float(tmp[1]  ) )
      tsrc = tsrc_
      qmass = qmass_

    if re.search( tag  ,   ll ) and once :
      dump =  1
      ct = 0 
      once = 0 

    ct = ct + 1

  f.close



  return store, tsrc, qmass


#
#  Read hadron data from a MILC data file
#
def extract_data_tsrc_at_mass(filename_in,tag,qmass_in):

#  print ("Reading data from  " , filename_in)
  try:
    f = open(filename_in, 'r')
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  store = [] 

  ct = 0 
  dump = 0  
  once = 0
  tsrc = -3
  tsrc_ = -2
  qmass = "XXX"

  for line in f:
    ct = ct + 1
    
    ll  = line.rstrip('\n')

    if "antiquark_source_origin" in ll :
       lls = ll.split()
#       print(ll)
#       print(lls[5])
       tsrc_ =  int( lls[5] )

    if re.search(r"^quark_mass" , ll ) :
      tmp = ll.split()
      qmass_ = re.sub("\"", "", tmp[1])
      qmass_f = float(qmass_)
      if qmass_f == qmass_in :
        once = 1

#      print(qmass_)

    if re.search( r'---'  ,   ll ) :
      dump = 0
      ct = 0 

    if dump  and ct > 2 :
      tmp = ll.split()
#      print(tmp[1])
      store.append(float(tmp[1]  ) )
      tsrc = tsrc_
      qmass = qmass_

    if re.search( tag  ,   ll ) and once :
      dump =  1
      ct = 0 
      once = 0 

    ct = ct + 1

  f.close



  return store, tsrc, qmass



#
#  Read hadron data from a MILC data file
#
def extract_data_AT_tsrc(filename_in,tag, tsrc_in):

#  print ("Reading data from  " , filename_in)
  try:
    f = open(filename_in, 'r')
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  store = [] 

  ct = 0 
  dump = 0  
  once = 1

  tsrc_ = -1
  qmass = "XXX"

  for line in f:
    ct = ct + 1

    ll  = line.rstrip('\n')

    if "antiquark_source_origin" in ll :
       lls = ll.split()
#       print(ll)
#       print(lls[5])
       tsrc_ =  int( lls[5] )

    if re.search(r"^quark_mass" , ll ) :
      tmp = ll.split()
      qmass_ = re.sub("\"", "", tmp[1])

    if re.search( r'---'  ,   ll ) :
      dump = 0
      ct = 0 

    if dump  and ct > 2 :
      tmp = ll.split()
#      print(tmp[1])
      store.append(float(tmp[1]  ) )
      qmass = qmass_

    if re.search( tag  ,   ll ) and once and tsrc_ == tsrc_in :
      dump =  1
      ct = 0 
      once = 0 

    ct = ct + 1

  f.close



  return store, qmass




def get_config_list(gdir) :

    clist = [] 
#    print ('Searching for configurations in ' , gdir)
    for filename in os.listdir(gdir):
           clist.append(filename)

    slist = sorted(clist)
    return slist

def get_config_list_tag(gdir, tag) :

    clist = [] 
#    print ('Searching for configurations in ' , gdir)
    for filename in os.listdir(gdir):
        if tag in filename :
           clist.append(filename)

    slist = sorted(clist)
    return slist



#################################

def timesym_corr(corr) :

   corrAv  = [] 
   tend    = len(corr)
   corrAv  = corr
   tmid = int( tend / 2 )

   for t in range(1 , tmid ) :
     tneg = tend - t 
     cc = ( corr[t] + corr[tneg] ) * 0.5 
#     print (t , tneg , corr[t] , corr[tneg] , " = " , cc )
     corrAv[t]    = cc
     corrAv[tneg] = cc

##   sys.exit(0) 
   return corrAv

#######################

#
#
#

def write_corr(cfglist, wdir, corr_tag, tag, timesym=0 ) :

  ff = tag + ".txt"
  print("Writing correlators to " , ff)

  f = open(ff, "w")
  for cfg in cfglist:
    fff = wdir + "/" + cfg
    corr = extract_data(fff,corr_tag)
    if timesym :
      corrA = timesym_corr(corr)
      corr  = corrA

##    print (tag, " " , end = "")
    f.write(tag + " " )
    ##  for cc in corrA  :
    for cc in corr  :
#       print(cc, " " ,  end = "" )
       f.write(str(cc) + " ")
#    print("")
    f.write("\n")

  f.close()


#
#
#
def write_header(f,nt) :
  f.write("corr_tag,sweep,tsrc,qmass")
  for t in range(0,nt):
    f.write("," + str(t) )
  f.write("\n" )

#
#
#

def write_corr_csv(cfglist, wdir, corr_tag, tag, nt, ff, append=False, timesym=0 ) :

##  ff = tag + ".csv"


  if append :
     print("Appending correlators to file " , ff)
     f = open(ff, "a")
  else:
     print("Writing correlators to new file " , ff)
     f = open(ff, "w")
     write_header(f,nt) 

  for cfg in cfglist:
    fff = wdir + "/" + cfg
    corr, tsrc, qmass = extract_data_tsrc(fff,corr_tag)
    if timesym :
      corrA = timesym_corr(corr)
      corr  = corrA

##    print (tag, " " , end = "")
    cfg_ = cfg.replace(tag,"")
#    print("DEBUG " , qmass, type(qmass))
    f.write(corr_tag + "," + cfg_ + "," + str(tsrc) + "," + str(qmass)  )
    ##  for cc in corrA  :
    for cc in corr  :
#       print(cc, "," ,  end = "" )
       f.write( "," + str(cc))
#    print("")
    f.write("\n")

  f.close()



#
#  Pass list of files and a function to extract configs
#

def write_corr_from_files_csv(filelist, get_cfg,wdir, corr_tag, f_tag, nt, ff, append=False, timesym=0 ) :

##  ff = tag + ".csv"


  if append :
     print("Appending correlators to file " , ff)
     f = open(ff, "a")
  else:
     print("Writing correlators to new file " , ff)
     f = open(ff, "w")
     write_header(f,nt) 

  for fname in filelist:
    fff = wdir + "/" + fname
    corr, tsrc, qmass = extract_data_tsrc(fff,corr_tag)
    if timesym :
      corrA = timesym_corr(corr)
      corr  = corrA

##    print (tag, " " , end = "")
##    cfg_ = cfg.replace(tag,"")
    cfg_ = get_cfg(fname,f_tag)
#    print("DEBUG " , qmass, type(qmass))
    f.write(corr_tag + "," + cfg_ + "," + str(tsrc) + "," + str(qmass)  )
    ##  for cc in corrA  :
    for cc in corr  :
#       print(cc, "," ,  end = "" )
       f.write( "," + str(cc))
#    print("")
    f.write("\n")

  f.close()



#
#
#

def write_corr_many_mass_csv(cfglist, wdir, corr_tag, tag, nt, mass_loop,ff, timesym=0 ) :

##  ff = tag + ".csv"
  if append :
     print("Appending correlators to file " , ff)
     f = open(ff, "a")
  else:
     print("Writing correlators to new file " , ff)
     f = open(ff, "w")
     write_header(f,nt) 


  for cfg in cfglist:
    fff = wdir + "/" + cfg
    for mass_ in mass_loop:
       corr, tsrc, qmass = extract_data_tsrc_at_mass(fff,corr_tag,mass_)
       if timesym :
          corrA = timesym_corr(corr)
          corr  = corrA

       cfg_ = cfg.replace(tag,"")
       f.write(corr_tag + "," + cfg_ + "," + str(tsrc) + "," + str(qmass)  )
       for cc in corr  :
          f.write( "," + str(cc))
       f.write("\n")

  f.close()



#
#
#

def write_corr_many_csv(cfglist, wdir, corr_tag, tag, tloop,nt,ff, append=False,timesym=0 ) :

##  ff = tag + ".csv"
  if append :
     print("Appending correlators to file " , ff)
     f = open(ff, "a")
  else:
     print("Writing correlators to new file " , ff)
     f = open(ff, "w")
     write_header(f,nt)

  for cfg in cfglist:
    fff = wdir + "/" + cfg
    for t_ in tloop :
      corr, qmass = extract_data_AT_tsrc(fff,corr_tag, t_)
      if timesym :
          corrA = timesym_corr(corr)
          corr  = corrA

      cfg_ = cfg.replace(tag,"")
      f.write(corr_tag + "," + cfg_ + "," + str(t_) + "," + str(qmass)   )
      for cc in corr  :
         f.write( "," + str(cc))
      f.write("\n")

  f.close()




#  Average over + and - charges
#
#

def write_corr_chargeAV(cfglist, wdirP, corr_tagP, wdirM, corr_tagM, tag, timesym=0 ) :

  ff = tag + ".txt"
  print("Writing correlators to " , ff)

  f = open(ff, "w")
  for cfg in cfglist:
    corrP = extract_data(wdirP + "/" + cfg ,corr_tagP)
    if timesym :
      corr_ = timesym_corr(corrP)
      corrP  = corr_
#    print("Number of P correlators " , len(corrP))

    corrM = extract_data(wdirM + "/" + cfg ,corr_tagM)
#    print("Number of M correlators " , len(corrM))
    if timesym :
      corr_ = timesym_corr(corrM)
      corrM  = corr_

##    print (tag, " " , end = "")
    f.write(tag + " " )
    ##  for cc in corrA  :
    for ccP,ccM in zip(corrP, corrM)  :
       cc = (ccP + ccM) / 2.0 
       f.write(str(cc) + " ")
#       print("P" , ccP, "M" , ccM)
    f.write("\n")

  f.close()


#  
#
#
def write_corr_at_time(cfglist, wdir, corr_tag, tag, tpt, timesym=0 ) :

  ff = tag + "_corr_t" + str(tpt) + ".txt"
  print("Writing correlators to " , ff)

  f = open(ff, "w")
  for cfg in cfglist:
    fff = wdir + "/" + cfg
    corr = extract_data(fff,corr_tag)
    if timesym :
      corrA = timesym_corr(corr)
      corr  = corrA

##    print (tag, " " , end = "")
    f.write(cfg + " " )
    corr_t = corr[tpt]
    f.write(str(corr_t) + "\n")

##  f.write("\n")

  f.close()
  return ff


def sort_cfg(cfglist, cname) :
  cfg_list = [] 
  for xx in cfglist:
     yy = xx.replace(cname,"")
     cfg_list.append(int(yy))

  tt = sorted(cfg_list, key=int)
  cfg_ = [] 
  for iii in tt:
     fff = cname + str(iii)
     cfg_.append(fff)

  return cfg_
