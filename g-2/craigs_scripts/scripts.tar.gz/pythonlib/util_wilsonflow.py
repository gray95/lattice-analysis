"""
  Routines to deal with Wilson flow data

"""

import os
import re
import sys




#
#
def extract_data(filename_in):
  """
     Load Wilson flow data from file
  """



#  print ("Reading data from  " , filename_in)
  try:
    f = open(filename_in, 'r')
  except:
    print ("Error opening " , filename_in)
    sys.exit(1)

  wflow = [] 
  tt  = [] 

  for line in f:
    
    ll  = line.rstrip('\n')
    lls = ll.split()

    tt.append(lls[1])      
    wflow_ = float(lls[2]) + float(lls[3])
    wflow.append(wflow_)

  f.close



  return tt, wflow


