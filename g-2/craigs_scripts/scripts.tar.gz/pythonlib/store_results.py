import pickle
import sys
from datetime import date

def to_pickle(fname, tt, corr, corr_err, qmass, noconfig) :


  print("Storing correlators to " , fname)
  today = date.today()
  print("Date = " , today)

  data = [ tt, corr, corr_err, qmass, noconfig , today  ]
  with open(fname, "wb") as f:
     pickle.dump(data, f)



def from_pickle(fname) :

  print("Loading correlators from " , fname)
  with open(fname, "rb") as f:
     data = pickle.load(f)

  try:
    tt       = data[0]
    corr     = data[1] 
    corr_err = data[2] 
    qmass    = data[3]
    noconfig = data[4]
    ddd      = data[5]

  except:
    print("Error extracting data from pickle")
    sys.exit(0)

  
  print("Quark mass = " , qmass)
  print("Number of configs = " , noconfig)
  print("Date of processing " , ddd)


  return tt,corr, corr_err
