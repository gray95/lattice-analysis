"""
  Common parameters to the analysis

"""

import re

nt = 48

##mass = "m0.001524"
##mass = "m0.003328"
mass = "m0.0677"


##mass = "m0.01698"
##mass = "m0.01213"
##mass = "m0.007278"

#  need to put disk in for gdata
#
wdir_fine = "gdata/" + mass
data_dir = "data"



